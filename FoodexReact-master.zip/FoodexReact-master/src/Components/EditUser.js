import React, {Fragment, useEffect, useState} from 'react';
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";
import EditUserInput from "./EditUserInput";


const EditUser = ({user, triggerUpdate}) => {
    const [userLocal, setUserLocal] = useState(null);
    const [response, loading, error, doFetch] = useAxios();


    const submitRegistro = () => {
        doFetch("post", "PUTDatosUsuario", userLocal);

    };
    useEffect(() => {
        response && triggerUpdate();
    }, [response]);
    useEffect(() =>
    {
        setUserLocal(user);


    }, [user]);

    let listItems = [];
    if (userLocal) {
       listItems = Object.keys(userLocal).map((key) => {
            return <EditUserInput user={userLocal} field={key} setUser={setUserLocal}/>
        });
    }


    return (
        <Fragment>

            <StatusDisplay loading={loading} error={error} response={response}/>
            {
                response && response.data.status == "ok" && "Cerrar Sesion para aplicar cambios"
            }
            <div id={"editUser"} class="modal fade" role="dialog">
                <div className="modal-dialog">

                    <div className="modal-content">
                        <div className="modal-header">
                            <h2 className="modal-title">Editar datos de usuario</h2>
                        </div>
                        <div className="modal-body">
                            <form onSubmit={e => {
                                e.preventDefault();
                                submitRegistro();
                            }
                            }>
                                {listItems}

                            </form>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-success" data-dismiss="modal" onClick={() => {
                                submitRegistro();
                            }}>Guardar Cambios
                            </button>
                            <button type="button" className="btn btn-danger" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>

                </div>
            </div>
        </Fragment>
    );
};

export default EditUser;
