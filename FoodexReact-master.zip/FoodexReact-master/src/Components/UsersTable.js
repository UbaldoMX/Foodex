import React, {useState} from 'react';
import PublicacionCard from "./PublicacionCard";
import UserRow from "./UserRow";
import EditUser from "./EditUser";
import DeleteUserModal from "./DeleteUserModal";

const UsersTable = (props) => {
    const [selected, setSelected] = useState(null);
    const listItems = props.users.map((x) => {
        return <UserRow key={x.IdUsuario} user={x} setSelected={setSelected}/>
    });
    return (
        <div>
            {selected && <EditUser user={selected} triggerUpdate={props.triggerUpdate}  />}
            {selected && <DeleteUserModal user={selected} triggerUpdate={props.triggerUpdate} /> }
            <table className="table">
                <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Email</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Ciudad</th>
                    <th scope="col">Acciones</th>

                </tr>
                </thead>
                <tbody>
                {listItems}

                </tbody>
            </table>

        </div>
    );
};

export default UsersTable;
