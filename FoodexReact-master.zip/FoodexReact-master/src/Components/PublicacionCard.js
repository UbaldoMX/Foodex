import React, {Fragment} from 'react';
import TimeAgo from "javascript-time-ago";
import es from 'javascript-time-ago/locale/es-MX'

TimeAgo.addLocale(es)
const timeAgo = new TimeAgo("es-MX");

const PublicacionCard = ({publicacion, userData, setSelected, setSelectedUser}) => {

    const update = () => {
        setSelectedUser(publicacion.IdUsuario);
    }

    const editPub = () => {
        setSelected(publicacion);
    }
    return (

        <div className={"col-sm-12 col-md-6 col-lg-4 col-xl-4"}>


            <div className="card text-white mb-3" style={{backgroundColor: '#73d573'}}>
                <h3 className="card-title text-center mt-3">{publicacion.Titulo}</h3>
                <div className="card-body text-center">
                    <p className="card-text text-white">{publicacion.Descripcion}</p>
                    <p className="card-text text-white" onClick={update} style={ {cursor: "pointer"} } data-toggle="modal"
                       data-target="#showAuthor"><i><u> Por {publicacion.Nombre}</u></i></p>
                    <p className="card-text text-white" data-toggle="tooltip" data-placement="top"
                       title={publicacion.Fecha}>{timeAgo.format(new Date(publicacion.Fecha + " UTC"))}</p>
                    {userData && (userData.userId == publicacion.IdUsuario || userData.Tipo == "admin") && <Fragment>
                        <button type="button" className="btn btn-primary mx-1" data-toggle="modal"
                                data-target="#editPub" onClick={editPub}><i className="fas fa-edit"></i>
                        </button>
                        <button type="button" className="btn btn-danger mx-1" data-toggle="modal"
                                data-target="#deletePub" onClick={editPub}><i className="fas fa-trash"></i>
                        </button>

                    </Fragment>}

                </div>

                <p></p>


            </div>
        </div>
    );
};

export default PublicacionCard;
