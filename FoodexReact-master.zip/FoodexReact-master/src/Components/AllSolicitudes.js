import React, {useEffect} from 'react';
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";
import PublicacionList from "./PublicacionList";

const AllSolicitudes = (props) => {
    const [response, loading, error, doFetch] = useAxios();

    const submit = () => {
        const payload = {};
        doFetch("post", "GETSolicitudes", payload);
    };

    useEffect(() => {
        submit();
    }, [props.update]);

    return (
        <div>
            {response != null &&
            <PublicacionList title={"Todas las Solicitudes"} publicaciones={response.data} userData={props.userData}
                             triggerUpdate={props.triggerUpdate}/>}
            <StatusDisplay loading={loading} error={error} response={response}/>
        </div>
    );
};

export default AllSolicitudes;
