import React from 'react';
import {Link} from "react-router-dom";
import {useLocation} from "react-router";


const LinkItem = (props) => {
    const location = useLocation();
    return (
        <li className={ (location.pathname == props.to) ? "active" : "" }><Link to={props.to}>{props.text}</Link></li>
    );
};

export default LinkItem;
