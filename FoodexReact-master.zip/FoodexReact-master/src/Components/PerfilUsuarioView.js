import React, {Fragment, useEffect} from 'react';
import {useAxios} from "../API/AxiosHook";
import RequireLogin from "./RequireLogin";
import EditPublicationForm from "./EditPublicationForm";
import EditUser from "./EditUser";
import {useRefresh} from "../API/RefreshHook";
import StatusDisplay from "./StatusDisplay";

const PerfilUsuarioView = ({IdUsuario, enableEdit}) => {
    const [response, loading, error, doFetch] = useAxios();
    const [update, triggerUpdate] = useRefresh();

    const submit  = () => {
        const payload = {
            "IdUsuario": IdUsuario
        };
        doFetch("post", "GETDatosUsuario", payload);
    };


    useEffect( () => {
        submit();
    }, [IdUsuario, update]);
    return (
        <Fragment>
            { enableEdit &&
            <button type="button" className="btn btn-info btn-lg my-3" data-toggle="modal"
                    data-target="#editUser">Editar Datos
            </button>
            }

            <StatusDisplay loading={loading} error={error} response={response}/>
            {response != null && response.data[0] != null &&
            <div>
                { enableEdit && <EditUser user={response.data[0]} triggerUpdate={triggerUpdate}/>}

                <p>Nombre: {response.data[0].Nombre}</p>
                <p>Telefono: {response.data[0].Telefono}</p>
                <p>Email: {response.data[0].Email}</p>
                <p>Calle: {response.data[0].Calle}</p>
                <p>Ciudad: {response.data[0].Ciudad}</p>
                <p>Colonia: {response.data[0].Colonia}</p>
                <p>Codigo Postal: {response.data[0].CodigoPostal}</p>
                {loading && <p>Cargando...</p>}
            </div>
            }
        </Fragment>
    );
};

export default PerfilUsuarioView;
