import React, {useEffect, useState} from 'react';
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";


const RegisterForm = () => {

    const [nombre, setNombre] = useState("");
    const [email, setEmail] = useState("");
    const [telefono, setTelefono] = useState("");
    const [password, setPassword] = useState("");

    const [calle, setCalle] = useState("");
    const [ciudad, setCiudad] = useState("");
    const [colonia, setColonia] = useState("");
    const [cp, setCp] = useState("");

    const submitRegistro = () => {
        const payload = {
            "Nombre": nombre,
            "Telefono": telefono,
            "Email": email,
            "Pass": password,
            "Calle": calle,
            "Ciudad": ciudad,
            "Colonia": colonia,
            "CodigoPostal": cp
        };
        doFetch("post", "Registro", payload);

        console.log(response);
    }


    const [response, loading, error, doFetch] = useAxios();


    return (
        <div>
            <div align="center" className="u-clearfix u-sheet u-valign-middle u-sheet-1">
                <h2 className="u-text u-text-custom-color-6 u-text-1">
                    <span style={{fontSize: '2rem'}}>Todos los campos con * son obligatorios</span>
                    <span style={{fontSize: '2rem'}}>
              <span style={{fontSize: '2rem'}}/>
            </span>
                </h2>
            </div>
            <form onSubmit={e => {
                e.preventDefault();
                submitRegistro();
            }
            } className="row g-3">

                <div align="center" className="u-clearfix u-sheet u-valign-middle u-sheet-1">

                </div>

                <div className="col-md-6">
                    <label htmlFor="inputNombre4" className="text-success">Nombre*</label>
                    <input type="Name" className="form-control" id="inputNamel4"
                           placeholder=" Escribe tu nombre completo" required value={nombre}
                           onChange={event => setNombre(event.target.value)}/>
                </div>
                <div className="col-md-6">
                    <label htmlFor="inputEmail4" className="text-success">Email*</label>
                    <input type="email" className="form-control" id="inputEmail4" placeholder=" example@gmail.com"
                           required autoComplete={"username"} value={email}
                           onChange={event => setEmail(event.target.value)}/>
                </div>
                <div className="col-md-6">
                    <label htmlFor="inputPassword4" className="text-success">Password*</label>
                    <input className="form-control" id="inputPassword4" placeholder="********" required value={password}
                           onChange={event => setPassword(event.target.value)} type={"password"}/>
                </div>
                <div className="col-md-6">
                    <label htmlFor="inputTel4" className="text-success">Teléfono*</label>
                    <input type="Phone" className="form-control" id="inputTel4" placeholder="(000) 000 00 00 " required
                           value={telefono} onChange={event => setTelefono(event.target.value)}/>
                </div>
                <div className="col-12">
                    <label htmlFor="inputAddress" className="text-success">Calle y número</label>
                    <input type="text" className="form-control" id="inputAddress" placeholder=" Ej. 21 poniente 1302"
                             value={calle} onChange={event => setCalle(event.target.value)}/>
                </div>
                <div className="col-md-8">
                    <label htmlFor="inputCity" className="text-success">Ciudad</label>
                    <input type="text" className="form-control" id="inputCity" placeholder="Escribe tu cuidad aquí "
                            value={ciudad} onChange={event => setCiudad(event.target.value)}/>
                </div>

                <div className="col-md-4">
                    <label htmlFor="inputZip" className="text-success">C.P.</label>
                    <input type="text" className="form-control" id="inputZip"
                           placeholder="Escribe tu codigo postal aquí "   value={cp} onChange={event => setCp(event.target.value)}/>
                </div>

                <div className="col-12 text-center my-3">
                    <button aling="center" type="submit" className="btn btn-success">Registrarse</button>
                </div>

            </form>

            <StatusDisplay loading={loading} error={error} response={response}/>

        </div>
    );
};

export default RegisterForm;
