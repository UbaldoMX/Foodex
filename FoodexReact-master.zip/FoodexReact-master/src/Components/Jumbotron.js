import React from 'react';

const Jumbotron = (props) => {
    return (
        <div className={"text-center"}>
            <h1 style={{color: '#73d573'}}>{props.text}</h1>
            {props.subtitle && <h4>{props.subtitle}</h4>}
            <div className="line" />
        </div>
    );
};

export default Jumbotron;
