import React, {Fragment, useEffect, useState} from 'react';
import StatusDisplay from "./StatusDisplay";
import InputText from "./InputText";
import RequireLogin from "./RequireLogin";
import {useAxios} from "../API/AxiosHook";

const EditPublicationForm = ({title, publicacion, triggerUpdate}) => {

    const [titulo, setTitulo] = useState("");
    const [descripcion, setDescripcion] = useState("");
    const [response, loading, error, doFetch] = useAxios();

    useEffect(() =>
    {
        setTitulo(publicacion.Titulo);
        setDescripcion(publicacion.Descripcion);
    }, [publicacion]);


    const submitRegistro = () => {
        const payload = {
            "Titulo": titulo,
            "Descripcion": descripcion,
            "IdDonacion": publicacion.IdDonacion

        };

        doFetch("put", "PUTSolicitud", payload);


    }

    useEffect(() => {
        response && triggerUpdate();
    }, [response]);
    return (
        <Fragment>

            <StatusDisplay loading={loading} error={error} response={response}/>

            <div id={"editPub"} class="modal fade" role="dialog">
                <div className="modal-dialog">

                    <div className="modal-content">
                        <div className="modal-header">
                            <h2 className="modal-title">Editar {title}</h2>
                        </div>
                        <div className="modal-body">
                            <form onSubmit={e => {
                                e.preventDefault();
                                submitRegistro();
                            }
                            }>
                                <div className="mb-3">
                                    <label htmlFor="Titulo" className="form-label">Titulo de {title}</label>
                                    <InputText name={"Titulo"} value={titulo} handleChange={setTitulo}/>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="Descripcion" className="form-label">Descripción de {title}</label>
                                    <textarea name={"Descripcion"} className="form-control" rows="3" onChange={event => setDescripcion(event.target.value)} value={descripcion}></textarea>
                                </div>
                            </form>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-success" data-dismiss="modal" onClick={e => {
                                submitRegistro();
                            }}>Editar {title}
                            </button>
                            <button type="button" className="btn btn-danger" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>





                </div>
            </div>
        </Fragment>
    );
};

export default EditPublicationForm;
