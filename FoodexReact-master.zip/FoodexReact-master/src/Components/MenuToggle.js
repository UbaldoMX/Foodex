import React from 'react';

const MenuToggle = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
                <button type="button" id="sidebarCollapse" className="btn btn-success" style={{backgroundColor: '#73d573', border: '1px #73d573 solid !important'}}>
                    <i className="fas fa-align-left" />
                    <span>Menu</span>
                </button>
            </div>
        </nav>
    );
};

export default MenuToggle;
