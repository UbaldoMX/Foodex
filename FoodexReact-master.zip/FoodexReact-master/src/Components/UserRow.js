import React from 'react';

const UserRow = ({user, setSelected}) => {

    const editUser = () => {
        setSelected(user);
    }

    return (
        <tr>
            <th scope="row">{user.IdUsuario}</th>
            <td>{user.Nombre}</td>
            <td>{user.Email}</td>
            <td>{user.Telefono}</td>
            <td>{user.Ciudad}</td>
            <td><button type="button" className="btn btn-primary mx-1" data-toggle="modal"
                        data-target="#editUser" onClick={editUser}>Actualizar
            </button>
                <button type="button" className="btn btn-danger mx-1" data-toggle="modal"
                        data-target="#deleteUser" onClick={editUser}>Eliminar
                </button></td>
        </tr>
    );
};

export default UserRow;
