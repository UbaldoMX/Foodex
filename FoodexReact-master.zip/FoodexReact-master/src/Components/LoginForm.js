import React, {useEffect, useState} from 'react';
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";

const LoginForm = (props) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [response, loading, error, doFetch] = useAxios();

    const submit = () => {
        const payload = {
            "Email": email,
            "Pass": password
        };
        doFetch("post", "Login", payload)
    }

    useEffect(() => {

        if (response != null && response.data[0]) {

            props.handleLogin(response.data[0].IdUsuario, response.data[0].Nombre, response.data[0].Tipo);

        }
    }, [response])

    return (
        <div>
            <form onSubmit={e => {
                e.preventDefault();
                submit();
            }
            }>
                <label className="text-success">Email:</label>
                <input type="text" className="form-control" name="username" placeholder="Email" autoComplete={"username"} required={true}
                       value={email} onChange={event => setEmail(event.target.value)}/>
                <label className="text-success" htmlFor="pwd">Password:</label>
                <input type="password" className="form-control" name="pwd" placeholder="*********" required={true}
                       autoComplete={"current-password"} value={password}
                       onChange={event => setPassword(event.target.value)} type={"password"}/>
                <div className={"text-center my-3"}>
                    <button className="btn btn-success btn-lg text-center">Iniciar sesión</button>

                </div>

            </form>

            <StatusDisplay loading={loading} error={error} response={response}/>
        </div>
    );
};

export default LoginForm;
