import React, {Fragment, useState} from 'react';
import PublicacionCard from "./PublicacionCard";
import UserModal from "./UserModal";
import EditPublicationForm from "./EditPublicationForm";
import DeletePublicationForm from "./DeletePublicationForm";

const PublicacionList = ({publicaciones, userData, triggerUpdate}) => {
    const [selected, setSelected] = useState(null);
    const [selectedUser, setSelectedUser] = useState(0);


    const listItems = publicaciones.map((x) => {
        return <PublicacionCard key={x.IdDonacion} publicacion={x} userData={userData} setSelectedUser={setSelectedUser}
                                setSelected={setSelected}/>
    });


    return (
        <Fragment>
            { selectedUser != 0 && <UserModal userId={selectedUser}/>}
            {selected && <EditPublicationForm publicacion={selected} title={"publicacion"} triggerUpdate={triggerUpdate}/>}
            {selected && <DeletePublicationForm publicacion={selected} triggerUpdate={triggerUpdate}/> }
            <div className={"container-fluid"}>
                <div className="card-deck row my-5">
                    {listItems}
                </div>
            </div>
        </Fragment>
    );
};

export default PublicacionList;
