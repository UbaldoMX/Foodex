import React, {Fragment, useEffect, useState} from 'react';

const StatusDisplay = (props) => {
    const [visible, setVisible] = useState(true);

    useEffect(() => {
        setVisible(true);
        setTimeout(() => {
            setVisible(false);
        }, 7000);
    }, [props.response]);

    return (
        <Fragment>
            <div className={"m-3"}>
                {props.loading &&
                <Fragment>
                    <div className="text-center">
                        <div className="spinner-border text-success ml-auto" role="status" aria-hidden="true"></div>
                    </div>
                </Fragment>}

                { visible && <Fragment>
                    {props.response && props.response.data.status && props.response.data.status == "ok" &&
                    <Fragment>
                        <div className="alert alert-success" role="alert">
                            <strong>OK!</strong> {props.response.data.status && props.response.data.message && props.response.data.message}
                            {props.response.data.status && props.response.data.mensaje && props.response.data.mensaje}
                        </div>
                    </Fragment>}

                    {props.response && props.response.data.status && props.response.data.status == "error" &&
                    <Fragment>
                        <div className="alert alert-danger" role="alert">
                            <strong>Error</strong> {props.response.data.status && props.response.data.message && props.response.data.message}
                            {props.response.data.status && props.response.data.mensaje && props.response.data.mensaje}
                        </div>
                    </Fragment>}

                    {props.error && <div className="alert alert-danger" role="alert">
                        Ocurrió un error inesperado
                    </div> && console.log(props.error)}
                </Fragment>}
            </div>
        </Fragment>

    );
};

export default StatusDisplay;
