import React, {Fragment, useEffect, useState} from 'react';
import InputText from "./InputText";
import SubmitButton from "./SubmitButton";
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";
import RequireLogin from "./RequireLogin";

const AddPublicationForm = (props) => {
    const [titulo, setTitulo] = useState("");
    const [descripcion, setDescripcion] = useState("");
    const [response, loading, error, doFetch] = useAxios();

    const submitRegistro = () => {
        const payload = {
            "tipo": props.tipo,
            "Titulo": titulo,
            "Descripcion": descripcion,
            "IdUsuario": props.userData.userId

        };

        doFetch("post", props.tipo, payload);

        console.log(props.userData.userId);
    }

    useEffect(() => {
        response && props.triggerUpdate();
    }, [response]);

    return (
        <Fragment>
            <button type="button" className="btn btn-info btn-lg mx-3" data-toggle="modal"
                    data-target="#addPub">Agregar {props.title}
            </button>
            <StatusDisplay loading={loading} error={error} response={response}/>

        <div id={"addPub"} class="modal fade" role="dialog">
            <div className="modal-dialog">

                <div className="modal-content">
                    <div className="modal-header">
                        <h2 className="modal-title">Agregar {props.title}</h2>
                    </div>
                    <div className="modal-body">
                        <form onSubmit={e => {
                            e.preventDefault();
                            submitRegistro();
                        }
                        }>
                            <div className="mb-3">
                                <label htmlFor="Titulo" className="form-label">Titulo de {props.title}</label>
                                <InputText name={"Titulo"} value={titulo} handleChange={setTitulo}/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Descripcion" className="form-label">Descripción de {props.title}</label>
                                <textarea name={"Descripcion"} className="form-control" rows="3" onChange={event => setDescripcion(event.target.value)} value={descripcion}></textarea>

                            </div>
                        </form>

                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-success" data-dismiss="modal" onClick={e => {
                            submitRegistro();
                        }}>Crear {props.title}
                        </button>
                        <button type="button" className="btn btn-danger" data-dismiss="modal">Cancelar</button>
                    </div>
                </div>




                <RequireLogin userData={props.userData}/>
            </div>
        </div>
        </Fragment>
    );
};

export default AddPublicationForm;
