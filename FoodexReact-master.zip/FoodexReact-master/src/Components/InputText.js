import React, {Fragment} from 'react';

const InputText = (props) => {
    return (
        <Fragment>
            <input type="text" className="form-control" value={props.value} onChange={event => props.handleChange(event.target.value)}/>
        </Fragment>
    );
};

export default InputText;
