// @flow 
import * as React from 'react';
import {Link} from "react-router-dom";
import {
    ROUTE_ADMIN_USERS,
    ROUTE_LOGIN,
    ROUTE_OFERTAS,
    ROUTE_PERFIL,
    ROUTE_REGISTER,
    ROUTE_SOLICITUDES
} from "../API/RouteConstants";
import {Fragment} from "react";
import LinkItem from "./LinkItem";


export const Menu = ( props ) => {

    return (

        <React.Fragment>
            <nav id="sidebar">

            <div className="sidebar-header">
                <h3>FOODEX</h3>
            </div>
            <ul className={"list-unstyled components"}>
                { props.userData && <p>{props.userData.Nombre}</p> }

                    <LinkItem to={"/"} text={"Inicio"}/>

                {
                    props.userData == null &&
                        <React.Fragment>
                            <LinkItem to={ROUTE_REGISTER} text={"Registrarse"}/>
                            <LinkItem to={ROUTE_LOGIN} text={"Iniciar sesión"}/>
                        </React.Fragment>
                }

                {props.userData &&
                    <Fragment>
                        <LinkItem to={ROUTE_OFERTAS} text={"Ofertas"}/>
                        <LinkItem to={ROUTE_SOLICITUDES} text={"Solicitudes"}/>
                        <LinkItem to={ROUTE_PERFIL} text={"Perfil"}/>
                        <li><Link to={"/"}onClick={props.handleLogOut}>Cerrar Sesion</Link></li>
                    </Fragment>
                }



                {props.userData && props.userData.Tipo == "admin" &&
                <Fragment>
                    <LinkItem to={ROUTE_ADMIN_USERS} text={"Administrar Usuarios"}/>
                </Fragment>
                }
            </ul>




            </nav>
        </React.Fragment>
    );
};
