import React, {Fragment, useEffect, useState} from 'react';

const EditUserInput = ({field, setUser, user}) => {
    const [value, setValue] = useState(user[field]);
    const updateUser = (val) => {
      let x = user;
        x[field] = val;
        console.log(x)
        setUser(x);
    };

    useEffect(() =>
    {
        updateUser(value);
    }, [value]);
    return (
        <Fragment>
            {field != "IdUsuario" &&

            <div className="mb-3">
                <label htmlFor={field} className="form-label">{field != "Pass"&& field || "Password"}</label>
                <input type={field == "Pass" && "password" || "text"} className="form-control" value={ value } onChange={event => { setValue(event.target.value) }}/>
            </div> }
        </Fragment>
    );
};

export default EditUserInput;
