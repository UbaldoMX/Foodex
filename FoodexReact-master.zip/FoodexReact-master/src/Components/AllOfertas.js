import React, {useEffect} from 'react';
import {useAxios} from "../API/AxiosHook";
import PublicacionList from "./PublicacionList";
import StatusDisplay from "./StatusDisplay";

const AllOfertas = (props) => {
    const [response, loading, error, doFetch] = useAxios();


    const submit = () => {
        const payload = {};
        doFetch("post", "GETOfertas", payload);
    };

    useEffect(() => {
        submit();
    }, [props.update]);

    return (
        <div>
            {response != null &&
            <PublicacionList title={"Todas las Ofertas"} publicaciones={response.data} userData={props.userData}
                             triggerUpdate={props.triggerUpdate}/>}
            <StatusDisplay loading={loading} error={error} response={response}/>
        </div>
    );
};
export default AllOfertas;
