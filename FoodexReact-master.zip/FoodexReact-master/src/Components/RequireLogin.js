import React from 'react';
import {Redirect} from "react-router";
import {ROUTE_LOGIN} from "../API/RouteConstants";

const RequireLogin = (props) => {
    return (
        <div>
            {props.userData == null && <Redirect to={ROUTE_LOGIN}></Redirect> }
        </div>
    );
};

export default RequireLogin;
