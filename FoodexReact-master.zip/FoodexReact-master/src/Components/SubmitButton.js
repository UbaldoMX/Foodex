import React from 'react';

const SubmitButton = (props) => {
    return (
        <input type={"submit"} value={props.name}/>
    );
};

export default SubmitButton;
