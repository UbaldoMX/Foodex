import React from 'react';
import RequireLogin from "./RequireLogin";
import PerfilUsuarioView from "./PerfilUsuarioView";

const UserModal = ({userId}) => {
    return (
        <div id={"showAuthor"} className="modal fade" role="dialog">
            <div className="modal-dialog">

                <div className="modal-content">
                    <div className="modal-header">
                        <h2 className="modal-title">Datos de Contacto</h2>
                    </div>
                    <div className="modal-body">

                        <PerfilUsuarioView IdUsuario={userId}/>
                    </div>
                    <div className="modal-footer">

                        <button type="button" className="btn btn-danger" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>



            </div>
        </div>
    );
};

export default UserModal;
