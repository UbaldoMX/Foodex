import React, {Fragment, useEffect, useState} from 'react';
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";

const DeleteUserModal = ({user, triggerUpdate}) => {

    const [titulo, setTitulo] = useState("");
    const [response, loading, error, doFetch] = useAxios();

    useEffect(() =>
    {
        setTitulo(user.Nombre);
    }, [user]);

    useEffect(() => {
        response && triggerUpdate();
    }, [response]);

    const submitRegistro = () => {
        const payload = {
            "IdUsuario": user.IdUsuario
        };

        doFetch("post", "DELETEDatosUsuario", payload);


    }
    return (
        <Fragment>

            <StatusDisplay loading={loading} error={error} response={response}/>

            <div id={"deleteUser"} class="modal fade" role="dialog">
                <div className="modal-dialog">

                    <div className="modal-content">
                        <div className="modal-header">
                            <h2 className="modal-title">Eliminar Usuario</h2>
                        </div>
                        <div className="modal-body">
                            <p>¿Seguro que desea Eliminar el usuario "{titulo}"?</p>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-dismiss="modal" onClick={() => {
                                submitRegistro();
                            }}>ELIMINAR
                            </button>
                            <button type="button" className="btn btn-primary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>





                </div>
            </div>
        </Fragment>
    );
};

export default DeleteUserModal;
