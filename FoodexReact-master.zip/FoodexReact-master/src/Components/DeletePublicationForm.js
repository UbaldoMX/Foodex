import React, {Fragment, useEffect, useState} from 'react';
import {useAxios} from "../API/AxiosHook";
import StatusDisplay from "./StatusDisplay";
import InputText from "./InputText";

const DeletePublicationForm = ({publicacion, triggerUpdate}) => {

    const [titulo, setTitulo] = useState("");
    const [response, loading, error, doFetch] = useAxios();

    useEffect(() =>
    {
        setTitulo(publicacion.Titulo);
    }, [publicacion]);

    useEffect(() => {
        response && triggerUpdate();
    }, [response]);

    const submitRegistro = () => {
        const payload = {
            "IdDonacion": publicacion.IdDonacion

        };

        doFetch("put", "DELETESolicitud", payload);


    }
    return (
        <Fragment>

            <StatusDisplay loading={loading} error={error} response={response}/>

            <div id={"deletePub"} class="modal fade" role="dialog">
                <div className="modal-dialog">

                    <div className="modal-content">
                        <div className="modal-header">
                            <h2 className="modal-title">Eliminar Publicacion</h2>
                        </div>
                        <div className="modal-body">
                            <p>¿Seguro que desea Eliminar "{titulo}"?</p>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-dismiss="modal" onClick={e => {
                                submitRegistro();
                            }}>ELIMINAR
                            </button>
                            <button type="button" className="btn btn-primary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </div>





                </div>
            </div>
        </Fragment>
    );
};

export default DeletePublicationForm;
