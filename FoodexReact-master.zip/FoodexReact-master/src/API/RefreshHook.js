import {useState} from "react";

export const useRefresh = () =>
{
    const [update, setUpdate] = useState(0);

    return [update, () => {
        setUpdate(update+1);
    }]
}
