export const ROUTE_REGISTER = "/register";
export const ROUTE_LOGIN = "/login";
export const ROUTE_OFERTAS = "/ofertas";
export  const ROUTE_SOLICITUDES = "/solicitudes"
export  const ROUTE_PERFIL = "/perfil"
export const ROUTE_ADMIN_USERS = "/admin/users"
