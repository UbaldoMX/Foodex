import {useEffect, useState} from "react";

/* Almacenar info de Login */

export const useLogin = () => {
    const [userData, setUserData] = useState(null)


    useEffect( () => {
        if (userData == null )
        {
            if (localStorage.getItem("userData"))
                setUserData(JSON.parse(localStorage.getItem("userData")));
        }
    }, []);

    const handleLogin = (userId, Nombre, Tipo) => {
        const user = {
            "userId": userId,
            "Nombre": Nombre,
            "Tipo": Tipo,
        }

        console.log(user);
        localStorage.setItem("userData", JSON.stringify(user));
        setUserData(user);
    }

    const handleLogOut = () => {
        localStorage.removeItem("userData");
        setUserData(null);
    }

    return [userData, handleLogin, handleLogOut];

}
