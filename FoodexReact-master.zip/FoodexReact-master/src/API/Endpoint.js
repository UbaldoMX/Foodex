export const ENDPOINT = "https://foodex-tsp.herokuapp.com/api/service/index.php"
