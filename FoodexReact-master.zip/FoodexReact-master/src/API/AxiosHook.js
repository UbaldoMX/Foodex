import {ENDPOINT} from "./Endpoint";
import React, {useState} from "react";
import axios from "axios";

export const useAxios = () => {
    const [response, setResponse] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    // [fetchNow, setFetchNow] = useState(false);
    const [verb, setVerb] = useState("");
    const [action, setAction] = useState("");
    const [payload, setPayload] = useState(null);
    const [url, setUrl] = useState(ENDPOINT);


    React.useEffect(() => {

        if (!action || !verb)
            return;
        //if (!fetchNow)
        //    return;

        //setFetchNow(false);

            if (payload)
        payload.tipo = action
        setLoading(true);

        axios({
            method: verb,
            url: url,
            data: payload,
            headers: {
                "Authorization": "123456"
            }
        })
            .then( response => {

                setResponse(response)

            })
            .catch( error => {
                setError(error)
                setLoading(false)
                console.log(error)
            })
            .then( () =>
            {
                setLoading(false)
            });

    }, [verb, action, payload, url]);


    return [response, loading, error, (verb, action, payload = null, url = ENDPOINT) => {
        setVerb(verb);
        setAction(action);
        setPayload(payload);
        setUrl(url);
    }]
}


