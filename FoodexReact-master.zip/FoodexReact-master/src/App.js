import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import {Menu} from "./Components/Menu";
import LandingHome from "./Pages/LandingPage/LandingHome";
import {
    ROUTE_REGISTER,
    ROUTE_LOGIN,
    ROUTE_SOLICITUDES,
    ROUTE_OFERTAS,
    ROUTE_PERFIL,
    ROUTE_ADMIN_USERS
} from "./API/RouteConstants";
import LoginPage from "./Pages/LoginPage";
import RegisterPage from "./Pages/RegisterPage";
import {useLogin} from "./API/LoginHook";
import SolicitudesPage from "./Pages/SolicitudesPage";
import OfertasPage from "./Pages/OfertasPage";
import PerfilPage from "./Pages/PerfilPage";
import MenuToggle from "./Components/MenuToggle";
import UsersPage from "./Pages/Admin/UsersPage";


function App() {

    const [userData, handleLogin, handleLogOut] = useLogin();

    return (
        <div className={"wrapper"}>

            <Router>

                <Menu userData={userData} handleLogOut={handleLogOut}/>


                <div id="content">
                    <MenuToggle/>

                    <Switch>
                        <Route path={ROUTE_REGISTER}>
                            <RegisterPage/>
                        </Route>
                        <Route path={ROUTE_LOGIN}>
                            <LoginPage handleLogin={handleLogin} userData={userData}/>
                        </Route>
                        <Route path={ROUTE_SOLICITUDES}>
                            <SolicitudesPage userData={userData}/>
                        </Route>
                        <Route path={ROUTE_OFERTAS}>
                            <OfertasPage userData={userData}/>
                        </Route>
                        <Route path={ROUTE_PERFIL}>
                            <PerfilPage userData={userData}/>
                        </Route>
                        <Route path={ROUTE_ADMIN_USERS}>
                            <UsersPage />
                        </Route>
                        <Route path={"/"}>
                            <LandingHome/>
                        </Route>


                    </Switch>
                </div>
            </Router>
        </div>
    );
}

export default App;
