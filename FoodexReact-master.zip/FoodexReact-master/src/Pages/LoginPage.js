import React from 'react';
import LoginForm from "../Components/LoginForm";
import {Redirect} from "react-router";
import {Link} from "react-router-dom";
import {ROUTE_REGISTER} from "../API/RouteConstants";

const LoginPage = (props) => {
    return (
        <div>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12"/>
                    <div className="col-12">
                        <div height="30%" width="100%" style={{border: 0, padding: '0px', margin: 0}}>
                            <br/>
                            <p>
                            </p><h1 className="text-success" style={{textAlign: 'center', fontSize: '6rem'}}>Iniciar
                            sesión</h1>
                            <span style={{fontSize: '4.5rem'}}>
                <span style={{fontSize: '6rem'}}/>
                <p/>
              </span></div>
                    </div>
                    <div className="col-4"/>
                    <div className="col-4">
                        <LoginForm handleLogin={props.handleLogin}/>
                    </div>
                    <div className="col-4"/>
                    <div className="col-12" style={{margin: '15px'}}/>
                    <div className="col-4"/>
                    <div className="col-4">

                    </div>
                    <div className="col-4"/>
                    <div className="col-12" style={{margin: '5px'}}/>
                    <div className="col-4"/>
                    <div className="col-4 text-center">
                        <Link className="btn btn-outline-info" to={ROUTE_REGISTER}>Registro</Link>

                    </div>
                </div>
            </div>


            {props.userData && <Redirect to={"/"}></Redirect>}
        </div>
    );
};

export default LoginPage;
