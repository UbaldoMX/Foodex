import React from 'react';
import AddPublicationForm from "../Components/AddPublicationForm";
import AllSolicitudes from "../Components/AllSolicitudes";
import {useRefresh} from "../API/RefreshHook";
import Jumbotron from "../Components/Jumbotron";

const SolicitudesPage = (props) => {

    const [update, triggerUpdate] = useRefresh();
    return (
        <div>
            <Jumbotron text={"Solicitudes"} subtitle={"Todas las Solicitudes"} />
            <AddPublicationForm userData={props.userData} tipo={"POSTSolicitud"} triggerUpdate={triggerUpdate} title={"Solicitud"}/>

            <AllSolicitudes update={update}  userData={props.userData} triggerUpdate={triggerUpdate}/>
        </div>
    );
};

export default SolicitudesPage;
