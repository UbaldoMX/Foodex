import React from 'react';

const LandingHome = () => {
    return (
       <iframe src={"/landing.html"} width={"100%"} height={"4830px"} seamless="seamless" scrolling={"no"} style={{border: 'none', overflow: 'hidden' }}/>
    );
};

export default LandingHome;
