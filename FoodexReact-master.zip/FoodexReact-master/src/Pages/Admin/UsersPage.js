import React, {useEffect} from 'react';
import {useAxios} from "../../API/AxiosHook";
import UsersTable from "../../Components/UsersTable";
import Jumbotron from "../../Components/Jumbotron";
import {useRefresh} from "../../API/RefreshHook";
import StatusDisplay from "../../Components/StatusDisplay";

const UsersPage = (props) => {

    const [response, loading, error, doFetch] = useAxios();
    const [update, triggerUpdate] = useRefresh();

    const submit  = () => {
        const payload = {

        };
        doFetch("post", "GETDatosUsuarios", payload);


    };

    useEffect( () =>{
        submit();
    }, [update]);
    return (
        <div>
            <Jumbotron text={"Usuarios Registrados"}/>
            {response != null && <UsersTable users={response.data} triggerUpdate={triggerUpdate}/> }
            <StatusDisplay loading={loading} error={error} response={response}/>
        </div>
    );
};

export default UsersPage;
