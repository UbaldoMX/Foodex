import React from 'react';
import RegisterForm from "../Components/RegisterForm";

const RegisterPage = () => {
    return (
        <div>
            <h2 className="text-success text-center">
                <span style={{fontSize: '6rem'}}>Regístrate</span>
                <span style={{fontSize: '4.5rem'}}>
              <span style={{fontSize: '6rem'}} />
            </span>
            </h2>
            <RegisterForm/>
        </div>
    );
};

export default RegisterPage;
