import React from 'react';
import AddPublicationForm from "../Components/AddPublicationForm";
import AllOfertas from "../Components/AllOfertas";
import {useRefresh} from "../API/RefreshHook";
import Jumbotron from "../Components/Jumbotron";

const OfertasPage = (props) => {
    const [update, triggerUpdate] = useRefresh();

    return (
        <div>
            <Jumbotron text={"Ofertas"} subtitle={"Todas las Ofertas"} />

            <AddPublicationForm  userData={props.userData} tipo={"POSTOferta"} triggerUpdate={triggerUpdate} title={"Oferta"}/>

            <AllOfertas update={update} userData={props.userData} triggerUpdate={triggerUpdate}/>
        </div>
    );
};

export default OfertasPage;
