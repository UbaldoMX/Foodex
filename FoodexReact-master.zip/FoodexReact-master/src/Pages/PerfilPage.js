import React from 'react';
import PerfilUsuarioView from "../Components/PerfilUsuarioView";
import Jumbotron from "../Components/Jumbotron";

const PerfilPage = (props) => {
    return (
        <div>

            {props.userData && <Jumbotron text={props.userData.Nombre} subtitle={"Datos de Usuario"} />}

            {props.userData && <PerfilUsuarioView IdUsuario={props.userData.userId} enableEdit/>}
        </div>
    );
}
;

export default PerfilPage;
